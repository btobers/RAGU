# RAGU - Radar Analysis Graphical Utility
#
# Copyright © 2020 btobers <tobers.brandon@gmail.com>
#
# Distributed under terms of the GNU GPL3.0 license.